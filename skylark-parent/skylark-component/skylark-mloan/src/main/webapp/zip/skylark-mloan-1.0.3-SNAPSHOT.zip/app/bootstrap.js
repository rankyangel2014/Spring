(function () {
'use strict';

angular
    .module('app')
    .config([
        '$stateProvider',
        '$urlRouterProvider',
        function (
            $stateProvider,
            $urlRouterProvider
        ) {
            $stateProvider.state('bootstrap', {
                url: '/',
                cache:'false',
                controller: 'Bootstrap',
            });

            $urlRouterProvider.otherwise('/');
        }
    ])
    .controller('Bootstrap', [
        '$state',
        '$cordovaSplashscreen',
        'jnConstant',
        'jnLogin',
        'jnLoginPopover',
        'jnGestureLoginPopover',
        'jnSetGesturePwdPopover',
        function (
            $state,
            $cordovaSplashscreen,
            jnConstant,
            jnLogin,
            jnLoginPopover,
            jnGestureLoginPopover,
            jnSetGesturePwdPopover
        ) {
            var goMain = function () {
                $state.go('main', {}, {
                    location: 'replace',
                });
            };

            document.addEventListener('deviceready', function () {
                $cordovaSplashscreen.hide();
                window.openOuterUrl = cordova.InAppBrowser.open;
            });

            if (jnLogin.isGestureSet()) {
                jnGestureLoginPopover.show({
                    onClose: function () {
                        jnConstant.init();
                        goMain();
                    }
                });

            } else {
                jnLoginPopover.show({
                    onClose: function () {
                        jnConstant.init();
                        jnSetGesturePwdPopover.show();
                        goMain();
                    }
                });
            }
        }
    ]);
})();
