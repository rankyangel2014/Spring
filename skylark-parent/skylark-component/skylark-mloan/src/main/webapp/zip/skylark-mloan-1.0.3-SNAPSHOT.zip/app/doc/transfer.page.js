(function () {
'use strict';

jn.angular.framePage({
    url: '/doc/transfer',
});
})();

