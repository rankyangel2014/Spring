/**
 * 提供数据库键值映射服务
 */

(function () {
'use strict';

angular
    .module('common')
    .factory('jnConstant', [
        'jnApp',
        'jnStorage',
        'jnHttp',
        function (
            jnApp,
            jnStorage,
            jnHttp
        ) {
            var STO_KEY_CONST = 'constants';
            var STO_KEY_ABBR = 'constantsAbbr';

            var KV = jnStorage.app.get(STO_KEY_CONST) || {};
            var ABBR = jnStorage.app.get(STO_KEY_ABBR) || {};

            return {
                /**
                 * 在登录之后调用
                 */
                init: function () {
                    var url = '/' + jnApp.id + '/js/param.do';
                    var type = jnApp.id + 'Params';

                    return jnHttp.get(url, {
                        type: type,
                    }).then(function (rsp) {
                        var k, v;

                        KV = {};
                        ABBR = {};

                        for (k in rsp.data) {
                            v = rsp.data[k];
                            k = k.replace(/^ITEM/, '');
                            KV[k] = {};
                            ABBR[k] = {};

                            v.forEach(function (p) {
                                KV[k][p.paramKey] = p.paramValue;
                                ABBR[k][p.paramKey] = p.shortDesc;
                            });
                        }

                        jnStorage.app.set(STO_KEY_CONST, KV);
                        jnStorage.app.set(STO_KEY_ABBR, ABBR);
                    });
                },

                get: function (num) {
                    return KV[num] || {};
                },

                getAbbr: function (num) {
                    return ABBR[num] || {};
                },
            };
        }
    ]);

})();
