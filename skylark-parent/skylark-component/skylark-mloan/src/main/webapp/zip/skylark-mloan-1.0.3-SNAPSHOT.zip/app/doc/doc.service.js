(function () {
'use strict';
angular
    .module('app')
    .factory('jnDoc', [
        '$q',
        'jnApp',
        'jnHttp',
        'jnHelper',
        function (
            $q,
            jnApp,
            jnHttp,
            jnHelper
        ) {
            var _cache = {};

            var _cacheNodes = function (pNodeId, nodes) {
                // 之所以把关联关系保存在子节点而不是父节点，
                // 是考虑到后一种实现需要先缓存父节点才能缓存子节点，
                // 假如遍历到某一层级时刷新页面，此时缓存丢失，将无法更新缓存。
                // 前一种实现虽然查找效率较低，但可保证在任何情况下都更新缓存。
                nodes.forEach(function (e) {
                    e.pNodeId = pNodeId;
                    _cache.nodes.push(e);
                });
            };

            var _cachedNode = function (nodeId) {
                return jnHelper.arrFind(_cache.nodes, function (e) {
                    return e.id === nodeId;
                });
            };

            var _cachedChildren = function (pNodeId) {
                return _cache.nodes.filter(function (e) {
                    return e.pNodeId === pNodeId;
                });
            };

            var _info = function (loanNo) {
                if (_cache.bnNo === loanNo) {
                    return $q(function (resolve, reject) {
                        resolve({
                            modelId: _cache.modelId,
                            orgNo: _cache.orgNo,
                        });
                    });
                }

                return jnHttp.post(
                    '/mloan/router/rest/ERecordAction.do?method=getModelIdByLoanNo',
                    {
                        bnNo: loanNo,
                    }
                ).then(function (rsp) {
                    _cache = {
                        bnNo: loanNo,
                        modelId: rsp.data.paramValue,
                        orgNo: rsp.data.orgNo,
                        nodes: [],
                    };

                    return {
                        modelId: rsp.data.paramValue,
                        orgNo: rsp.data.orgNo,
                    };
                });
            };

            var service = {};

            /**
             * bnNo 贷款合同号
             * nodeId
             * pNodeId
             */
            service.readDirList = function (params) {
                var p = {
                    bnNo: params.bnNo,
                };

                return _info(params.bnNo).then(function (rsp) {
                    var cached = _cachedChildren(params.nodeId);

                    if (0 < cached.length) {
                        return cached;
                    }

                    p.modelId = rsp.modelId;

                    if (0 === params.nodeId) {
                        p.node = 'root_0';
                        p.pNodeId = 0;
                    } else {
                        p.node = params.nodeId;
                        p.pNodeId = params.nodeId;
                    }

                    return jnHttp.post(
                        '/mloan/router/rest/ERecordAction.do?method=getTreeNodeList',
                        p
                    ).then(function (rsp) {
                        var nodes = rsp.map(function (e) {
                            return jnHelper.refine(e, [
                                'id',
                                'text',
                                'leaf',
                            ]);
                        });

                        var pNode = _cachedNode(params.nodeId);

                        if (pNode) {
                            nodes.forEach(function (e) {
                                e.path = pNode.path.concat(pNode.text);
                            });

                        } else {
                            nodes.forEach(function (e) {
                                e.path = [];
                            });
                        }

                        if (void 0 !== params.pNodeId) {
                            nodes.unshift({
                                id: params.pNodeId,
                                text: '..',
                                leaf: false,
                            });
                        }

                        _cacheNodes(params.nodeId, nodes);

                        return nodes;
                    });
                });
            };

            var getModelId = function (bnNo) {
                return jnHttp.post(
                    '/mloan/router/rest/ERecordAction.do?method=getModelIdByLoanNo',
                    {
                        bnNo: bnNo,
                        paramName: 'bef_model_id',
                    }
                ).then(function (rsp) {
                    return rsp.data.paramValue;

                });
            };

            /**
             * bnNo
             * modelId*
             */
            service.readDirTree = (function () {
                var parseNode = function (node, pNode) {
                    var n = {
                        id: node.id,
                        text: node.text,
                        parent: pNode,
                    };

                    if ('N' === node.isLeaf) {
                        n.children = node.children.map(function (e) {
                            return parseNode(e, n);
                        });
                    }

                    return n;
                };

                var getTree = function (bnNo, modelId) {
                    return jnHttp.post(
                        '/mloan/router/rest/ERecordAction.do?method=getTreeNodeList', {
                            bnNo: bnNo,
                            modelId: modelId,
                        }).then(function (rsp) {
                            var tree = {
                                model: modelId,
                            };

                            tree.children = rsp.map(function (e) {
                                return parseNode(e, tree);
                            });

                            return tree;
                        });
                };

                return function (params) {
                    if (params.modelId) {
                        return getTree(params.bnNo, params.modelId);
                    }

                    return getModelId(params.bnNo).then(function (modelId) {
                        return getTree(params.bnNo, modelId);
                    });
                };
            })();

            /**
             * bnNo 贷款合同号
             * nodeId
             */
            service.readFileList = function (params) {
                return _info(params.bnNo)
                    .then(function (rsp) {
                        params.orgNo = rsp.orgNo;

                        return jnHttp.post(
                            '/mloan/router/rest/ERecordAction.do?method=getFileList',
                            params
                        );
                    }).then(function (rsp) {
                        return {
                            total: rsp.total,
                            items: rsp.root.map(function (e) {
                                e = jnHelper.refine(e, [
                                    'crtDate',
                                    'fileNo',
                                    'fileName',
                                    'fileVName',
                                    'filePath',
                                    'fileSize',
                                    'userName',
                                ]);

                                e.url = jnApp.baseUrl + '/' + e.filePath
                                    + e.fileVName;

                                return e;
                            }),
                        };
                    });
            };

            /**
             * custNo
             * bnNo 贷款合同号
             * fileType
             * fileNo
             * nodeId
             */
            service.deleteFile = function (params) {
                params = jnHelper.merge({
                    operate: 1,
                    bnType: 10,
                }, params);

                return jnHttp.post(
                    '/mloan/router/rest/ERecordAction.do?method=uploadFileData',
                    params
                );
            };

            /**
             * custNo
             * bnNo 贷款合同号
             * fileType
             * fileNo
             * fileRName
             */
            service.updateFile = function (params) {
                params = jnHelper.merge({
                    operate: 2,
                    bnType: 10,
                }, params);

                return jnHttp.post(
                    '/mloan/router/rest/ERecordAction.do?method=uploadFileData',
                    params
                );
            };

            /**
             * bnNo 贷款合同号
             * keyword
             */
            service.searchDir = function (params) {
                var service = this;

                if (params.keyword) {
                    return (function () {
                        var findInNode = function (matches, path, nodeId) {
                            return service.readDirList({
                                bnNo: params.bnNo,
                                nodeId: nodeId,
                            }).then(function (rsp) {
                                rsp.forEach(function (e) {
                                    if (e.text.match(params.keyword)) {
                                        // e.path = path;
                                        matches.push(e);
                                    }
                                });

                                var branches = rsp.filter(function (e) {
                                    return ! e.leaf;
                                });

                                var promises = branches.map(function (e) {
                                    /*
                                    return findInNode(matches,
                                        path.concat(e.text), e.id);
                                    */

                                    return findInNode(matches,
                                        null, e.id);
                                });

                                return $q.all(promises);
                            });
                        };

                        var matches = [];

                        return findInNode(matches, [], 0).then(function () {
                            return matches;
                        });
                    })();

                } else {
                    return this.readDirList({
                        bnNo: params.bnNo,
                        nodeId: 0,
                    });
                }
            };

            /**
             * custNo
             * bnNo 贷款合同号
             * nodeId
             * modelNo
             * fileData
             * fileName
             * width
             * height
             */
            service.uploadFile = function (params) {
                params = jnHelper.merge({
                    operate: 0,
                    bnType: 10,
                    thumbName: 'xxx',
                }, params);

                return jnHttp.post(
                    '/mloan/router/rest/ERecordAction.do?method=uploadAttachment',
                    params,
                    {
                        quiet: true,
                    }
                ).then(function (rsp) {
                    return {
                        file: rsp.data.fileSrc,
                        thumb: rsp.data.thumbSrc,
                    };
                });
            };

            /**
             * bnNo 贷款合同号
             */
            service.readAllFiles = (function () {
                var SUPPORTED_FILE_TYPES = [
                    'jpg',
                    'jpeg',
                    'png',
                    'gif',
                    'tif',
                    'tiff',
                ];

                var isSupported = function (filename) {
                    var ext = jn.util.extFromFilename(filename);
                    return -1 < SUPPORTED_FILE_TYPES.indexOf(ext);
                };

                var parse = function (rsp) {
                    var groups = {};
                    var list = [];
                    var k;

                    rsp.root.forEach(function (e) {
                        var path = e.nodePath;

                        if (! isSupported(e.fileName)) {
                            return;
                        }

                        if (! groups[path]) {
                            groups[path] = [];
                        }

                        groups[path].push({
                            id: e.fileNo,
                            cdate: e.crtDate,
                            name: e.fileName,
                            size: e.fileSize,
                            fileSrc: jn.util.joinPath(
                                jnApp.baseUrl, e.fileSrc),
                            thumbSrc: jn.util.joinPath(
                                jnApp.baseUrl, e.thumb),
                            modelNo: e.modelNo,
                            nodeId: e.nodeId,
                        });
                    });

                    for (k in groups) {
                        list.push({
                            path: k.split('>'),
                            files: groups[k],
                        });
                    }

                    return list;
                };

                return function (params) {
                    params = jnHelper.merge(params, {
                        bnType: 10,
                    });

                    if (params.modelNo) {
                        return jnHttp.post(
                            '/mloan/router/rest/ERecordAction.do?method=getAllFileList',
                            params
                        ).then(parse);
                    }

                    return getModelId(params.bnNo).then(function (modelNo) {
                        params.modelNo = modelNo;

                        return jnHttp.post(
                            '/mloan/router/rest/ERecordAction.do?method=getAllFileList',
                            params
                        ).then(parse);
                    });
                };
            })();

            service.getUploadMaxSize = (function () {
                var size;

                return function () {
                    if (size) {
                        return $q(function (resolve, reject) {
                            resolve(size);
                        });
                    }

                    return jnHttp.post(
                        '/mloan/router/rest/param.do?method=getOrgParamByCode',
                        {
                            parCde: 'MAX_PIC_UNCONDENSE_SIZE',
                        }
                    ).then(function (res) {
                        size = res.parValue;
                        return size;
                    });
                };
            })();

            Object.defineProperties(service, {
                model: {
                    get: function () {
                        return _cache.modelId;
                    },
                }
            });

            return service;
        }]
    );
})();
