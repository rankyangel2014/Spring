(function () {
'use strict';

angular
    .module('common')
    .directive('jnBack', [
        'jnPage',
        function (jnPage) {
            return {
                template: '\
<button\
    class="button button-clear ion-chevron-left jnBack"\
>返回</button>',

                restrict: 'E',

                link: function ($scope, $element, $attr) {
                    $element.on('click', function () {
                        jnPage.back();
                    });
                },
            };
        }]
    );

})();
